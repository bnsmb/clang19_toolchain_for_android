/*
 * This file is auto-generated. Modifications will be lost.
 *
 * See https://android.googlesource.com/platform/bionic/+/master/libc/kernel/
 * for more information.
 */
#ifndef _UAPI__ASM_ARM_SWAB_H
#define _UAPI__ASM_ARM_SWAB_H
#include <linux/compiler.h>
#include <linux/types.h>
#ifndef __STRICT_ANSI__
#define __SWAB_64_THRU_32__
#endif
#ifndef __thumb__
#endif
#define __arch_swab32 __arch_swab32
#endif
