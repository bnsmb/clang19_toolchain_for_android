#pragma once

/**
 * @file sys/fcntl.h
 * @brief Historical synonym for `<fcntl.h>`.
 *
 * New code should use `<fcntl.h>` directly.
 */

#include <fcntl.h>
