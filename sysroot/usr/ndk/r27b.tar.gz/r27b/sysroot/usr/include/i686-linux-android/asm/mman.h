/*
 * This file is auto-generated. Modifications will be lost.
 *
 * See https://android.googlesource.com/platform/bionic/+/master/libc/kernel/
 * for more information.
 */
#ifndef _ASM_X86_MMAN_H
#define _ASM_X86_MMAN_H
#define MAP_32BIT 0x40
#define MAP_ABOVE4G 0x80
#define SHADOW_STACK_SET_TOKEN (1ULL << 0)
#include <asm-generic/mman.h>
#endif
