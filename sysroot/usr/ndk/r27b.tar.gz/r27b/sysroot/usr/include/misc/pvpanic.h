/*
 * This file is auto-generated. Modifications will be lost.
 *
 * See https://android.googlesource.com/platform/bionic/+/master/libc/kernel/
 * for more information.
 */
#ifndef __PVPANIC_H__
#define __PVPANIC_H__
#define PVPANIC_PANICKED (1 << 0)
#define PVPANIC_CRASH_LOADED (1 << 1)
#endif
