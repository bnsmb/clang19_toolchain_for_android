/*
 * This file is auto-generated. Modifications will be lost.
 *
 * See https://android.googlesource.com/platform/bionic/+/master/libc/kernel/
 * for more information.
 */
#ifndef _UAPI_ASM_X86_BOOT_H
#define _UAPI_ASM_X86_BOOT_H
#define NORMAL_VGA 0xffff
#define EXTENDED_VGA 0xfffe
#define ASK_VGA 0xfffd
#endif
